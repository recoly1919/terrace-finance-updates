# Terrace Finance V2.4.0 — Gelirler ve alacaklar

V2.3.1 üzerine kurulmuş, yerel SQLite verisini koruyan ve mevcut **Ed25519 imzalı güncelleme sistemiyle uyumlu** geliştirme.

## Neler eklendi?
- **Gelirler / Para Girişleri:** satış tahsilatı, diğer ticari gelir, ortak sermayesi, kredi/borç girişi, tedarikçi iadesi, ticari olmayan diğer girişler; tarih, tutar (RMB), kaynak, ödeme yöntemi, referans ve not.
- **Alacaklar:** kişi/şirket, vade, tutar, kısmi tahsilat, bakiye ve tahsilat geçmişi. Fazla tahsilat engellenir. Kayıtlar ara/filtrele ve sayfalama ile yönetilir.
- **Genel Bakış:** nakit girişleri, gerçekleşen ödemeler, net kayıtlı nakit hareketi, açık alacaklar, son altı ay giriş/çıkış grafiği; Finans Bülteni'nde yaklaşan/gecikmiş alacaklar.
- **Excel:** yeni “Para Girişleri” ve “Alacaklar” sayfaları; özetin nakit hareketi satırları.
- **Türkçe / 中文** alan ve kategori çevirileri. İşlem geçmişinde yeni kayıt türleri.

## Finansal hesaplama ilkeleri
- Ortak sermayesi, alınan borç ve gider iadesi **ticari gelir / kâr olarak sayılmaz**.
- Gelir tablosundaki “tahsil edilen ticari gelir”, **nakit esasına göre** yalnızca `Satış tahsilatı` ve `Diğer ticari gelir` kayıtlarıdır. Tahsil edilmemiş alacaklar nakit girişine eklenmez.
- “Net kayıtlı nakit hareketi” = kaydedilen **para girişleri − gerçekleşmiş gider ödemeleri**. Açılış bakiyesi, işletme banka hesabı mutabakatı ve gerçek kasa bakiyesi değildir.
- Bu sürüm bir tam muhasebe, KDV/fapiao, tahakkuk esaslı kâr-zarar, POS veya bordro sistemi değildir. Ekipmanların amortismanı ve satılan ürünlerin maliyeti ayrı modellenmelidir.
- Tedarikçiden geri alınan kaporalar burada iade olarak para girişine kaydedilir. Eski gider kaydı ve bağlı ödemenin tutarı otomatik değiştirilmez; gerekirse işleme ayrıca açıklama ekleyin.

## Uygulama içi otomatik güncelleme ile dağıtım (ÖNERİLEN)

**Özel imza anahtarınızı kesinlikle paylaşmayın.** GitHub yalnızca paket ZIP ve imzalı manifest'i barındırır.

1. `TerraceFinance_V2_4_0_Kaynak.zip` dosyasını Mac'inizde açın. `terrace-finance-v2.4` klasörünü `~/Desktop/Finans App/` içine yerleştirin.
2. Yeni bir Terminal penceresinde (çalışan sunucunun Terminal'inde değil) imza/paketleme komutunu çalıştırın:

   ```bash
   bash ~/Desktop/"Finans App"/terrace-finance-v2.4/yayinla_mac.sh
   ```

3. İki dosya oluşturulur: `~/TerraceRelease/public/packages/TerraceFinance_2.4.0_Mac.zip` ve `~/TerraceRelease/public/stable/manifest.json`.
4. GitHub deposunda **önce ZIP'i** `packages/` klasörüne, ardından `manifest.json` dosyasını `stable/` klasörüne yükleyip commit edin. `signing.key` dosyasını asla yüklemeyin.
5. GitHub Pages dağıtımı tamamlandıktan sonra Terrace Finance V2.3.1 → **Güncellemeler → Kontrol Et**. V2.4.0 görüldüğünde önce ayrıca **Tam yedek** indirin; ardından uygulama içinden yükleyin.
6. Uygulama kendini yeniden başlatır. `Genel Bakış`, `Gelirler / Para Girişleri`, `Alacaklar` ve `Güncellemeler` ekranlarını kontrol edin.

### Manuel kurtarma / alternatif
Önce uygulamayı durdurun. Var olan uygulama `~/Desktop/"Finans App"/terrace-finance` klasöründeyse:

```bash
bash ~/Desktop/"Finans App"/terrace-finance-v2.4/upgrade_mac.sh ~/Desktop/"Finans App"/terrace-finance
cd ~/Desktop/"Finans App"/terrace-finance && bash start.sh
```

Güncelleme betiği otomatik yedek oluşturur ve eski veritabanını korur. **Ana uygulamanın `data/` klasörünü veya eski yedekleri silmeyin.**

## Yayın ve test notu
Kaynak kodu sözdizimi, veritabanı yükseltmesi, API işlevleri, Excel, sahte test anahtarıyla imzalı yayın doğrulaması ve statik tarayıcı render'ı test edilmiştir. Gerçek Mac/Pages üzerinden uçtan uca V2.4.0 dağıtımı, kullanıcı özel anahtarı burada bulunmadığından henüz gerçekleştirilmemiştir.

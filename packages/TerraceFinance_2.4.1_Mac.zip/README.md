# Terrace Finance V2.4.1 — Etkileşimli nakit akışı

V2.4.0 üzerinde hazırlanmış, veritabanı şemasını değiştirmeyen arayüz güncellemesi.

- Genel Bakış → Aylık Nakit Giriş / Çıkışı bölümünde her ayın yeşil ve mavi sütunları tıklanabilir.
- Üzerine gelince veya klavyeyle odaklanınca ay, toplam RMB tutarı ve kayıt sayısı görüntülenir.
- Yeşil sütun → seçilen ayın **Gelirler / Para Girişleri** geçmişi.
- Mavi sütun → seçilen ayın **Ödemeler** geçmişi. İptal edilen harcama kayıtlarına bağlı ödemeler grafikle tutarlı şekilde hariç tutulur.
- Ay başlığı → o ayın girişleri.
- Geçmiş sayfasında **Ay filtresini temizle** düğmesi vardır. Mevcut 30/40 kayıt sayfalaması korunur.
- Türkçe ve Çince metinler desteklenir.

## Güvenli kurulum

1. Dosyayı açın ve `terrace-finance-v2.4.1` klasörünü `~/Desktop/Finans App/` içine koyun.
2. Mevcut uygulamada önce **Tam Yedek** alın.
3. Yeni Terminal penceresinde `bash ~/Desktop/"Finans App"/terrace-finance-v2.4.1/yayinla_mac.sh` çalıştırın.
4. Mac'inizde üretilen `~/TerraceRelease/public/packages/TerraceFinance_2.4.1_Mac.zip` paketini önce GitHub `packages/` klasörüne, ardından `~/TerraceRelease/public/stable/manifest.json` içeriğini `stable/manifest.json` dosyasına yükleyin.
5. Güncelleme sunucusunda V2.4.1 yayına girdikten sonra uygulama içi **Güncellemeler** ekranından yükleyin.

**Gizlilik:** `~/TerracePublisherSecrets/signing.key` dosyasını hiçbir yere yüklemeyin. Bu güncelleme başka kullanıcıların verilerini düzenleme yetkisi eklemez; ayrı bir geliştirme gerektirir.

**Testler:** JavaScript sözdizimi, Python sözdizimi ve grafik tıklama/filtre davranışı için otomatik birim testleri başarılı. Bu ortamda Chromium eksik olduğundan görsel tarayıcı testi yapılmadı.
